import requests
import json
import time

# 模拟 API 调用的全局函数
def global_api_call(endpoint):
    try:
        response = requests.get(f"https://api.example.com/{endpoint}")
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        return {"error": str(e)}

# 辅助类
class DataProcessor:
    def process_data(self, data):
        # 模拟数据处理
        processed = {k: v.upper() if isinstance(v, str) else v for k, v in data.items()}
        return processed

    def api_data_enrichment(self, data):
        # 模拟通过 API 调用丰富数据
        try:
            response = requests.post("https://api.enrichment.com/process", json=data)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            return {"error": str(e)}

# 主类
class DataManager:
    def __init__(self, api_key):
        self.api_key = api_key
        self.processor = DataProcessor()

    def fetch_and_process_data(self, user_id):
        # 调用全局 API 函数
        user_data = global_api_call(f"users/{user_id}")
        
        if "error" in user_data:
            return {"status": "error", "message": user_data["error"]}

        # 使用辅助类处理数据
        processed_data = self.processor.process_data(user_data)

        # 模拟另一个 API 调用
        try:
            analytics_response = requests.get(
                f"https://api.analytics.com/user-stats/{user_id}",
                headers={"Authorization": f"Bearer {self.api_key}"}
            )
            analytics_response.raise_for_status()
            analytics_data = analytics_response.json()
        except requests.RequestException as e:
            return {"status": "error", "message": f"Analytics API error: {str(e)}"}

        # 合并数据
        combined_data = {**processed_data, "analytics": analytics_data}

        # 使用辅助类进行数据丰富
        enriched_data = self.processor.api_data_enrichment(combined_data)

        return {"status": "success", "data": enriched_data}

# 测试代码
if __name__ == "__main__":
    # 创建 DataManager 实例
    data_manager = DataManager("your_api_key_here")
    
    # 调用方法
    result = data_manager.fetch_and_process_data("user123")
    
    # 打印结果
    print(json.dumps(result, indent=2))

    # 注意：这个示例代码在实际运行时会失败，因为它使用了虚构的 API 端点
    # 在实际应用中，您需要替换这些 URL 和 API 密钥为真实的值